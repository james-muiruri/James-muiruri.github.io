---
layout: single
title: "Contact Me"
permalink: /contact/
---

Feel free to reach out for collaboration, job opportunities, or tech discussions.

📧 **Email:** [your-email@example.com](mailto:jamesmuiruri820@gmail.com)  
📞 **Phone:** +254704070009
🔗 **LinkedIn:** [View My Profile](https://www.linkedin.com/in/james-muiruri-325b23258)

---

I’m open to internships, full-time roles, or freelance projects in networking, support, and cybersecurity.
