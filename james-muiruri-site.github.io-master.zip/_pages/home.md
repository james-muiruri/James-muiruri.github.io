---
layout: splash
title: "Hi, I'm James Muiruri"
permalink: /
header:
  overlay_image: /assets/images/hero.jpg
  overlay_filter: rgba(0,0,0,0.4)
  caption: "Network Specialist | Developer | Tech Enthusiast"
  actions:
    - label: "Explore Projects"
      url: "/projects/"
---

> “The goal is not to be better than anyone else, but to be better than you used to be.” — James Muiruri

{% include feature_row %}