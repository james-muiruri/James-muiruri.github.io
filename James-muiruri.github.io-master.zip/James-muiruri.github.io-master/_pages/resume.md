---
layout: single
title: "Resume"
permalink: /resume/
---

You can download my full resume here:

👉 [Download My Resume (PDF)](/assets/files/james-muiruri-resume.pdf)

---

### Summary

Experienced IT Support and Network Technician with a passion for cybersecurity and continuous self-improvement through labs and certifications.

- **BSc. Math & Computer Science**
- **Hands-on experience** in networking and system maintenance
- **Strong foundation** in cybersecurity principles
